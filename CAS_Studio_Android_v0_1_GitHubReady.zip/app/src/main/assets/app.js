import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";
import { OrbitControls } from "https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/controls/OrbitControls.js";

const state = {
  faceWidth:0, faceLength:0, jawWidth:0, cheekWidth:0, eyeSize:0, eyeSpacing:0,
  noseWidth:0, lipSize:0, warmth:0, blush:0.08, hairLength:0.12,
  skin:"#8a4e36", hair:"long", makeup:false, earrings:false, gloss:false
};

const canvas=document.querySelector("#avatarCanvas");
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.setSize(canvas.clientWidth,canvas.clientHeight,false);
renderer.outputColorSpace=THREE.SRGBColorSpace;

const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(32,1,.1,100);
camera.position.set(0,0.05,5.2);
const controls=new OrbitControls(camera,canvas);
controls.enablePan=false; controls.minDistance=3.8; controls.maxDistance=7;
controls.target.set(0,0.1,0);

scene.add(new THREE.HemisphereLight(0xffffff,0x333333,2.2));
const key=new THREE.DirectionalLight(0xffffff,2.2); key.position.set(2,4,5); scene.add(key);
const rim=new THREE.DirectionalLight(0xffd9ea,1.4); rim.position.set(-4,2,-2); scene.add(rim);

const avatar=new THREE.Group(); scene.add(avatar);
const head=new THREE.Mesh(new THREE.SphereGeometry(1,64,48),new THREE.MeshStandardMaterial({color:state.skin,roughness:.62}));
head.scale.set(1.02,1.18,0.92); head.position.y=.35; avatar.add(head);

const neck=new THREE.Mesh(new THREE.CylinderGeometry(.32,.38,.75,32),head.material.clone());
neck.position.y=-.75; avatar.add(neck);

const shoulder=new THREE.Mesh(new THREE.SphereGeometry(1,32,16),new THREE.MeshStandardMaterial({color:0x19191d,roughness:.8}));
shoulder.scale.set(1.35,.48,.58); shoulder.position.y=-1.25; avatar.add(shoulder);

const eyeMat=new THREE.MeshStandardMaterial({color:0x141114,roughness:.35});
const whiteMat=new THREE.MeshStandardMaterial({color:0xf8f4ef,roughness:.4});
const lipMat=new THREE.MeshStandardMaterial({color:0x9b5962,roughness:.45});
const noseMat=new THREE.MeshStandardMaterial({color:state.skin,roughness:.62});

function makeEye(){const g=new THREE.Group();
  const white=new THREE.Mesh(new THREE.SphereGeometry(.17,32,20),whiteMat);
  white.scale.set(1.15,.72,.42); white.position.z=.88; g.add(white);
  const iris=new THREE.Mesh(new THREE.SphereGeometry(.075,24,16),eyeMat);
  iris.position.set(0,0,.13); g.add(iris); return g;
}
const leftEye=makeEye(),rightEye=makeEye(); avatar.add(leftEye,rightEye);

const nose=new THREE.Mesh(new THREE.ConeGeometry(.16,.42,32),noseMat);
nose.rotation.x=Math.PI/2; nose.position.set(0,.16,.95); avatar.add(nose);

const lips=new THREE.Mesh(new THREE.SphereGeometry(.2,32,16),lipMat);
lips.scale.set(1.25,.42,.32); lips.position.set(0,-.18,.91); avatar.add(lips);

const hairGroup=new THREE.Group(); avatar.add(hairGroup);
function rebuildHair(){
  hairGroup.clear();
  const mat=new THREE.MeshStandardMaterial({color:0x141116,roughness:.48});
  if(state.hair==="locs"){
    for(let i=-7;i<=7;i++){const c=new THREE.Mesh(new THREE.CapsuleGeometry(.055,.9+Math.random()*.35,6,10),mat); c.position.set(i*.11,.7-(Math.abs(i)*.015),.12); c.rotation.z=i*.035; hairGroup.add(c);}
  } else if(state.hair==="curly"){
    for(let i=0;i<26;i++){const a=(i/26)*Math.PI*2; const c=new THREE.Mesh(new THREE.TorusGeometry(.16,.055,10,18),mat); c.position.set(Math.cos(a)*.8,.4+Math.sin(a)*.75,.1); c.rotation.y=a; hairGroup.add(c);}
  } else if(state.hair==="bob"){
    const cap=new THREE.Mesh(new THREE.SphereGeometry(1.12,48,32),mat); cap.scale.set(1.03,1.12,.95); cap.position.y=.53; hairGroup.add(cap);
  } else {
    const cap=new THREE.Mesh(new THREE.SphereGeometry(1.12,48,32),mat); cap.scale.set(1.06,1.18,.98); cap.position.y=.58; hairGroup.add(cap);
    const length=1.35+state.hairLength;
    [-.82,.82].forEach(x=>{const side=new THREE.Mesh(new THREE.CapsuleGeometry(.18,length,12,18),mat); side.position.set(x,.05,.08); hairGroup.add(side);});
  }
}
rebuildHair();

function apply(){
  head.scale.x=1.02+state.faceWidth; head.scale.y=1.18+state.faceLength; head.scale.z=.92;
  shoulder.scale.x=1.35+state.jawWidth*.4;
  leftEye.scale.setScalar(1+state.eyeSize); rightEye.scale.setScalar(1+state.eyeSize);
  leftEye.position.x=-.36-state.eyeSpacing; rightEye.position.x=.36+state.eyeSpacing;
  nose.scale.x=1+state.noseWidth;
  lips.scale.set(1.25+state.lipSize,.42+state.lipSize*.4,.32);
  const c=new THREE.Color(state.skin); noseMat.color.copy(c); head.material.color.copy(c); neck.material.color.copy(c);
  hairGroup.scale.y=1+state.hairLength*.18;
}
apply();

function resize(){const w=canvas.clientWidth,h=canvas.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
addEventListener("resize",resize); resize();

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab,.tab-content").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.getElementById(b.dataset.tab).classList.add("active")});

document.querySelectorAll('input[type="range"]').forEach(input=>{
  const key=input.dataset.key, out=document.getElementById(key+"Out");
  const update=()=>{state[key]=parseFloat(input.value); if(out)out.value=Number(state[key]).toFixed(2); apply()};
  input.addEventListener("input",update); update();
});

const skinColors=["#4a251d","#603226","#76402e","#8a4e36","#a85f42","#c37b5b","#d99a78","#e5b092","#f0c7ad","#e8ad91","#b87959","#8d533e"];
const swatches=document.querySelector("#skinSwatches");
skinColors.forEach(c=>{const b=document.createElement("button");b.className="swatch";b.style.background=c;b.title=c;b.onclick=()=>{document.querySelectorAll(".swatch").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");state.skin=c;apply()};swatches.appendChild(b)});
swatches.firstChild.classList.add("selected");

document.querySelectorAll(".hair-card").forEach(b=>b.onclick=()=>{document.querySelectorAll(".hair-card").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");state.hair=b.dataset.hair;rebuildHair()});
document.querySelector("#makeupBtn").onclick=()=>{state.makeup=!state.makeup;document.querySelector("#makeupBtn").textContent=state.makeup?"On":"Off";lipMat.color.set(state.makeup?"#b54f6b":"#9b5962")};
document.querySelector("#earringBtn").onclick=()=>{state.earrings=!state.earrings;document.querySelector("#earringBtn").textContent=state.earrings?"On":"Off"};
document.querySelector("#glossToggle").onchange=e=>state.gloss=e.target.checked;

document.querySelector("#resetBtn").onclick=()=>location.reload();

document.querySelector("#saveBtn").onclick=()=>{
  const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob); const a=document.createElement("a");a.href=url;a.download="cas-studio-character.json";a.click();URL.revokeObjectURL(url);
};

function animate(){requestAnimationFrame(animate);renderer.render(scene,camera)} animate();
