# CAS Studio Android v0.1

Phone-first Android wrapper for the CAS Studio prototype.

## Build
The included GitHub Actions workflow builds a debug APK in the cloud. No computer is required after the repository is connected to GitHub.

## Important
This is the visual prototype only. It does not modify The Sims FreePlay. The next milestone is replacing the procedural placeholder avatar with a proper stylized 3D character mesh and morph-target system.
